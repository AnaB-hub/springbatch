package com.springbatch.demonstrativoorcamentario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemonstrativoOrcamentarioJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
